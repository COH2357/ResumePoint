@echo off
rem ============================================================
rem  Windows 11 新版媒体播放器 断点续播 —— 探针一键运行器
rem  用法：双击运行，或命令行  run-probe.cmd [-SeekToSeconds 600]
rem  注意：需 Windows PowerShell 5.1（本脚本已显式调用 powershell.exe）
rem ============================================================
setlocal
cd /d "%~dp0"

echo.
echo  [!] 请先在 Windows 11 媒体播放器里播放一个视频（SMTC 会话只在播放时存在）
echo.
echo  [!] 按任意键开始探测...
echo.
pause >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Probe-MediaPlayerResume.ps1" %*

echo.
echo  探测结束。按任意键关闭窗口。
pause >nul
