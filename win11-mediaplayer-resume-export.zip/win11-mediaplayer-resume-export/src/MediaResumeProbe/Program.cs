// =============================================================================
//  Windows 11 新版媒体播放器 —— 断点续播探针（C# / .NET 8 + WinRT 投影）
//
//  与 probe/Probe-MediaPlayerResume.ps1 等价，作为 PowerShell WinRT await 桥
//  不稳时的备选。
//
//  运行：
//      dotnet run --project src/MediaResumeProbe
//      dotnet run --project src/MediaResumeProbe -- --seek 600
//
//  前置：先在 Windows 11 媒体播放器里播放一个视频（SMTC 会话只在播放时存在）。
// =============================================================================

using System.Text.Json;
using System.Text.Json.Nodes;
using Windows.Media.Control;

const string TargetAumid = "Microsoft.ZuneMusic_8wekyb3d8bbwe!Microsoft.ZuneMusic";
const string PackageFamilyName = "Microsoft.ZuneMusic_8wekyb3d8bbwe";

// ------------------------------------------------------------------ 参数解析
long seekToTicks = -1;
for (int i = 0; i < args.Length; i++)
{
    if (args[i] == "--seek" && i + 1 < args.Length && long.TryParse(args[i + 1], out long sec))
    {
        seekToTicks = TimeSpan.FromSeconds(sec).Ticks;
        i++;
    }
}

Console.OutputEncoding = System.Text.Encoding.UTF8;

void Section(string t)
{
    Console.WriteLine();
    Console.WriteLine(new string('=', 78));
    Console.WriteLine($"  {t}");
    Console.WriteLine(new string('=', 78));
}
void Ok(string m) => Console.WriteLine($"  [OK]   {m}");
void Warn(string m) => Console.WriteLine($"  [WARN] {m}");
void Bad(string m) => Console.WriteLine($"  [FAIL] {m}");
void Info(string m) => Console.WriteLine($"  [INFO] {m}");

// ============================================================ [1] 包身份
Section("[1] 包身份 / AUMID");
string installLocation = null;
try
{
    var pkg = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("powershell.exe")
    {
        RedirectStandardOutput = true,
        UseShellExecute = false,
        ArgumentList = { "-NoProfile", "-Command", "(Get-AppxPackage Microsoft.ZuneMusic).InstallLocation" }
    });
    installLocation = pkg.StandardOutput.ReadToEnd().Trim();
    pkg.WaitForExit();
    if (!string.IsNullOrWhiteSpace(installLocation)) Ok($"InstallLocation : {installLocation}");
    else Warn("未查到 InstallLocation（包可能未安装）");
}
catch (Exception ex) { Warn($"包查询失败: {ex.Message}"); }
Ok($"AUMID           : {TargetAumid}");

// ============================================================ [2] 断点落盘
Section("[2] 断点数据落盘位置 (LocalState)");
var stateDir = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
    "Packages", PackageFamilyName, "LocalState");

var appStatePath = Path.Combine(stateDir, "AppState.json");
if (File.Exists(appStatePath))
{
    Ok($"AppState.json : {appStatePath}");
    try
    {
        using var doc = JsonDocument.Parse(await File.ReadAllTextAsync(appStatePath));
        var root = doc.RootElement;

        if (root.TryGetProperty("PlayQueueModel", out var q) &&
            q.TryGetProperty("Items", out var items) && items.ValueKind == JsonValueKind.Array)
        {
            foreach (var it in items.EnumerateArray())
            {
                var src = it.TryGetProperty("Source", out var s) ? s.GetString() : null;
                var kind = it.TryGetProperty("Kind", out var k) ? k.ToString() : "?";
                Info($"队列项 Source = {src}   (Kind={kind})");
            }
        }

        if (root.TryGetProperty("PlayerModel", out var pm) &&
            pm.TryGetProperty("CurrentPosition", out var cp))
        {
            var raw = cp.GetString();
            Ok($"PlayerModel.CurrentPosition = {raw}");
            if (TimeSpan.TryParse(raw, out var ts))
                Info($"  → 换算 = {ts:hh\\:mm\\:ss\\.fff}");
            else
                Warn("  → 不是合法 TimeSpan 字符串（该版本可能改了结构）");
        }
        else
        {
            Warn("PlayerModel.CurrentPosition 缺失（该版本可能改了结构）");
        }
        Info("注意：该字段只保存「当前队列项」的单一断点，不是 per-file 断点表。");
    }
    catch (Exception ex) { Bad($"解析 AppState.json 失败: {ex.Message}"); }
}
else
{
    Warn($"未找到 {appStatePath}");
    if (Directory.Exists(stateDir))
    {
        Info("LocalState 目录内容：");
        foreach (var f in Directory.EnumerateFiles(stateDir).Take(30))
            Info("   " + Path.GetFileName(f) + $"  ({new FileInfo(f).Length} bytes)");
    }
}

var dbPath = Path.Combine(stateDir, "MediaPlayer.db");
if (File.Exists(dbPath))
    Ok($"MediaPlayer.db : {dbPath}  （只有最近播放时间戳，没有位置列）");
else
    Warn("未找到 MediaPlayer.db");

// ============================================================ [3] SMTC 会话
Section("[3] SMTC 全局媒体会话（生死判定）");
GlobalSystemMediaTransportControlsSession target = null;
try
{
    var mgr = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
    var sessions = mgr.GetSessions().ToList();
    Ok($"当前系统媒体会话数: {sessions.Count}");

    foreach (var s in sessions)
    {
        var id = s.SourceAppUserModelId;
        var isTarget = string.Equals(id, TargetAumid, StringComparison.OrdinalIgnoreCase)
                       || id.StartsWith("Microsoft.ZuneMusic", StringComparison.OrdinalIgnoreCase);
        Info($"会话: {id}{(isTarget ? "   <<<< 新版媒体播放器" : "")}");

        try
        {
            var info = s.GetPlaybackInfo();
            Info($"   状态={info.PlaybackStatus}  可Seek={info.Controls.IsPlaybackPositionEnabled}");
        }
        catch (Exception ex) { Warn($"   读 PlaybackInfo 失败: {ex.Message}"); }

        try
        {
            var tl = s.GetTimelineProperties();
            Info($"   位置={tl.Position}  时长={tl.EndTime}  Min={tl.MinSeekTime}  Max={tl.MaxSeekTime}");
        }
        catch (Exception ex) { Warn($"   读 TimelineProperties 失败: {ex.Message}"); }

        try
        {
            var mp = await s.TryGetMediaPropertiesAsync();
            Info($"   媒体属性: Title='{mp.Title}' Artist='{mp.Artist}' Album='{mp.AlbumTitle}'");
        }
        catch { /* 取不到媒体属性不影响判定 */ }

        if (isTarget && target is null) target = s;
    }

    Console.WriteLine();
    if (target is not null)
    {
        Ok("★ 新版媒体播放器确实注册了 SMTC 会话 —— 「外部读位置」成立。");
        var seekable = false;
        try { seekable = target.GetPlaybackInfo().Controls.IsPlaybackPositionEnabled; } catch { }
        if (seekable) Ok("★ IsPlaybackPositionEnabled = True —— 「外部写位置（seek）」也成立。");
        else Warn("IsPlaybackPositionEnabled = False —— 外部 seek 大概率被拒，路线风险高。");
    }
    else
    {
        Warn("未发现新版媒体播放器的 SMTC 会话。");
        Info("可能原因：播放器没在播放任何内容（会话只在播放时出现），或它不注册 SMTC。");
        Info("判定：先在媒体播放器里播一个视频，再重跑本程序看 [3]。");
    }
}
catch (Exception ex)
{
    Bad($"SMTC 探测失败: {ex.Message}");
    Info("提示：GSMTC 需要交互式桌面会话（不能在服务 / 计划任务 / 无头会话里跑）。");
}

// ============================================================ [4] 可选 seek
if (seekToTicks >= 0)
{
    Section($"[4] 外部 seek 写测试 → {TimeSpan.FromTicks(seekToTicks).TotalSeconds} 秒");
    if (target is not null)
    {
        try
        {
            bool ok = await target.TryChangePlaybackPositionAsync(seekToTicks);
            if (ok) Ok("TryChangePlaybackPositionAsync 返回 True —— 外部跳转成功，路线成立 ✅");
            else
            {
                Warn("TryChangePlaybackPositionAsync 返回 False —— 播放器拒绝了这次跳转。");
                Info("若此时播放器确实在播放，通常说明它没实现 PlaybackPositionChangeRequested。");
            }
        }
        catch (Exception ex) { Bad($"seek 调用异常: {ex.Message}"); }
    }
    else Warn("没有可用的目标会话，跳过 seek。请先让媒体播放器开始播放，再重跑。");
}

// ============================================================ 汇总
Section("判定汇总");
Console.WriteLine("""
  路线 A「系统播放器 + 外部伴生工具」成立：
    [3] 出现 Microsoft.ZuneMusic 会话  且  IsPlaybackPositionEnabled = True
    → 可做：外部读断点 + 外部 seek + IExplorerCommand 右键入口

  路线 B「换 mpv」：
    [3] 无该会话，或 IsPlaybackPositionEnabled = False
    → mpv.conf 写 save-position-on-quit=yes，0.5–2 人时搞定，零风险

  无论哪种，「双击文件是否自动续播」仍需人工三组对照确认：
    资源管理器双击 / Home 最近播放点入 / 完全退出后重开
""");
